from django.urls import path
from app1.views import planetView, galaxyView, showplanet, showgalaxy, updateView, deleteView

urlpatterns = [
    path('pv/', planetView, name='planeturl'),
    path('gv/', galaxyView, name='galaxyurl'),
    path('sp/', showplanet, name='showplaneturl'),
    path('sg/', showgalaxy, name='showgalaxyurl'),
    path('uv/<int:id>/', updateView, name='updateurl'),
    path('dv/<int:id>/', deleteView, name='deleteurl')
]
