from django.db import models

# Create your models here.
class Planet(models.Model):
    position = models.IntegerField(primary_key=True)
    pname = models.CharField(max_length=100)
    sat = models.IntegerField()

    def __str__(self):
        return self.pname

class Galaxy(models.Model):
    planet = models.OneToOneField(Planet, on_delete=models.CASCADE)
    sun = models.CharField(max_length=100)

    def __str__(self):
        return self.planet
