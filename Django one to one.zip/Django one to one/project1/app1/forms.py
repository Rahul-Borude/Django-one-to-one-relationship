from django import forms
from app1.models import Planet, Galaxy

class PlanetForm(forms.ModelForm):
    class Meta:
        model = Planet
        fields = "__all__"
    
class GalaxyForm(forms.ModelForm):
    class Meta:
        model = Galaxy
        fields = "__all__"