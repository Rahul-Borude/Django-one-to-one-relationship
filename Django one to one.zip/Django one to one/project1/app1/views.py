from re import template
from turtle import position
from django.shortcuts import render, redirect
from app1.models import Planet, Galaxy
from app1.forms import PlanetForm, GalaxyForm
# Create your views here.

def planetView(request):
    form = PlanetForm()
    template_name = "app1/addplanet.html"
    context = {'form':form}
    if request.method == "POST":
        form = PlanetForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, template_name, context)

def galaxyView(request):
    form = GalaxyForm()
    template_name = "app1/addgalaxy.html"
    context = {'form':form}
    if request.method == "POST":
        form = GalaxyForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, template_name, context)

def showplanet(request):
    obj = Planet.objects.all()
    template_name = "app1/showplanet.html"
    context = {'obj':obj}
    return render(request, template_name, context)

def showgalaxy(request):
    obj = Galaxy.objects.all()
    template_name = "app1/showgalaxy.html"
    context = {'obj':obj}
    return render(request, template_name, context)

def updateView(request, id):
    obj = Galaxy.objects.get(id = id)
    form = GalaxyForm(instance=obj)
    template_name = "app1/addgalaxy.html"
    if request.method == "POST":
        form = GalaxyForm(request.POST, instance=obj)
        print
        if form.is_valid():
            form.save()
            return redirect('showgalaxyurl')
    context = {'form':form}
    return render(request, template_name, context)

def deleteView(request, id):
    obj = Planet.objects.get(position = id)
    template_name = "app1/confirmation.html"
    context = {'data':obj}
    if request.method == "POST":
        obj.delete()
        return redirect('showgalaxyurl')
    return render(request, template_name, context)